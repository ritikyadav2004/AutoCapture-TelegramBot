chrome.runtime.sendMessage({ action: "captureAndSend" });
